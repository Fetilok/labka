package com.example.lab2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        val dropdown = findViewById<Spinner>(R.id.dropdown)
//        dropdown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
//                val selectedItem = parent.getItemAtPosition(position).toString()
//                Toast.makeText(this@MainActivity, "$selectedItem вибрано", Toast.LENGTH_SHORT).show()
//            }
//
//            override fun onNothingSelected(parent: AdapterView<*>) {}
//        }
        val dropdown = findViewById<Spinner>(R.id.dropdown)
        val button = findViewById<Button>(R.id.Get)
        button.setOnClickListener {
            val selectedItem = dropdown.selectedItem.toString()
            Toast.makeText(this@MainActivity, "$selectedItem вибрано", Toast.LENGTH_SHORT).show()
        }

        dropdown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                // Обробник подій для випадаючого списку
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
//        val messageEditText = findViewById<EditText>(R.id.messageEditText)
//        val sendButton = findViewById<Button>(R.id.sendButton)
//
//        sendButton.setOnClickListener {
//            val message = messageEditText.text.toString()
//
//            // Створюємо нову активність, передаємо їй повідомлення та запускаємо її
//            val intent = Intent(this, MessageActivity::class.java).apply {
//                putExtra("message", message)
//            }
//            startActivity(intent)
//        }
        val messageEditText = findViewById<EditText>(R.id.messageEditText)
        val sendButton = findViewById<Button>(R.id.sendButton)

        sendButton.setOnClickListener {
            val message = messageEditText.text.toString()

            // Створюємо інтент з ACTION_SEND та передаємо повідомлення
            val intent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, message)
                type = "text/plain"
            }

            // Показуємо діалогове вікно з вибором додатку для відправки повідомлення
            startActivity(Intent.createChooser(intent, "Надіслати повідомлення за допомогою"))
        }

    }
}

class MessageActivity {

}
